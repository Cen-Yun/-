import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*1，创建StrutsHibernateMysql对象用于调用StrutsHibernateMysql方法
        * 2，创建Scanner对象对键盘录入学生学号，用while语句反复运行程序
        * 3，switch分支语句对需要的功能进行处理*/
        StrutsHibernateMysql shm=new StrutsHibernateMysql();
        shm.students.add(new Student(001,"ccy",22,"罗赖"));
        while (true) {
            System.out.println("----欢迎来到学生管理系统\n1 添加学生\n2 删除学生\n3 修改学生\n4 查看学生\n5 查看所有学生\n6 退出\n");
            Scanner sc = new Scanner(System.in);
            System.out.println("请输入");
            int index = sc.nextInt();
            switch (index) {
                case 1://添加学生
                    shm.add();
                    break;
                case 2://删除学生
                    System.out.println("请输入学生学号  如：001");
                    shm.delect(sc.nextInt());
                    break;
                case 3://修改学生
                    System.out.println("请先输入学号查询是否存在该学生");
                        index = sc.nextInt();
                        shm.revamp( index);
                    break;
                case 4:
                    System.out.println("请输入学生学号");
                    shm.exists(sc.nextInt());
                    break;
                case 5://查看所有学生
                    shm.look();
                    System.out.println("查询完毕");
                    break;
                case 6://退出
                    shm.exit();
                    break;
                default://输入没有的选项，返回主界面
                    System.out.println("没有这个选项，请返回");
                    break;
            }
        }
    }
}