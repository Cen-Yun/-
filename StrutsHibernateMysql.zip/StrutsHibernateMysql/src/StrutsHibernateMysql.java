import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class StrutsHibernateMysql {
    /*1，创建ArrayList与Scanner对象，用于存储学生信息和键盘录入
    * 2，add()添加学生
    * 3，delect()删除学生方法
    * 4，revamp()修改学生方法
    * 5，look()查看所有学生方法
    * 6，exit()结束程序
    * 7，getIndex() 获取从键盘输入学生ID对应索引方法
    * 8，exists()判断学生是否存在方法
    * 9，print()打印制控制台*/
        ArrayList<Student> students=new ArrayList<>();

            Scanner sc=new Scanner(System.in);
        void add(){//添加学生
            System.out.println("请输入学生信息:id+姓名+年龄+住址");
            System.out.println("请输入学号");
            int id = sc.nextInt();
            if (exists(id)==false) {//如果学生存在，不存储
                System.out.println("请输入姓名");
                String name = sc.next();
                System.out.println("请输入年龄");
                int age = sc.nextInt();
                System.out.println("请输入住址");
                String address = sc.next();
                students.add(new Student(id, name, age, address));
            }else {
                System.out.println("学生已存在");
            }
        }
        void delect(int index){//加学生删除
                    Student stu = students.remove(getIndex(index));
                    print(stu);
//                    System.out.println("删除成功："+"学号："+remove1.getId()+"  姓名："+remove1.getName()+"  年龄："+remove1.getAge()+"  住址："+remove1.getAddress()+"\n");
        }
        void revamp(int index){//删除学生
            if (exists(index)){
                System.out.println("请输入学生信息:id+姓名+年龄+住址");
                System.out.println("请输入学号");
                int id = sc.nextInt();
                System.out.println("请输入姓名");
                String name = sc.next();
                System.out.println("请输入年龄");
                int age = sc.nextInt();
                System.out.println("请输入住址");
                String address = sc.next();
                students.set(getIndex(index),new Student(id,name,age,address));
                System.out.println("修改成功!");
            }
        }
        void look(){//查看所有学生
            for (var e:students
                 ) {
                print(e);
            }
        }
        void exit(){//退出系统
            System.out.println("感谢您的使用，再见。");
            System.exit(0);
        }
        int getIndex(int index){//获取指定学号在数组中的索引
            for (int i = 0; i < students.size(); i++) {
                if (index==students.get(i).getId()){
                    return i;
                }
            }
            return -1;
        }
        boolean exists(int index){//查看学生是否存在
            /*if (getIndex(index) == -1)return false;
            return true;*/
            for (var e:students
                 ) {
                if (e.getId()==index){
                    System.out.println("学生存在：");
                    print(e);
                    return true;
                }
            }
            return false;
        }
         void print(Student e){//打印
            System.out.println("学号："+e.getId()+"  姓名："+e.getName()+"  年龄："+e.getAge()+"  住址："+e.getAddress());
        }
}
